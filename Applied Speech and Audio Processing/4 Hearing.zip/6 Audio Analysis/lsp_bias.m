function [bias] = lsp_bias(w)
    bias=sum(w)/length(w);

