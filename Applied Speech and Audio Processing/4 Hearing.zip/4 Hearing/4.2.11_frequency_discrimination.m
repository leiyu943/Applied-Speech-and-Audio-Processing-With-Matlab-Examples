t1=tonegen(1000, 8000, 2);
t2=tonegen(1002, 8000, 2);
soundsc(t1, 8000);
soundsc(t2, 8000);
