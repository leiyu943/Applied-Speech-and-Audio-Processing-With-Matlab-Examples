lo=0.2*tonegen(800, 8000, 2);
hi=tonegen(880, 8000, 2);

sound(lo/2, 8000);
sound(hi/2, 8000);
sound((lo+hi)/2, 8000);

