lo= tonegen(250, 441000, 2);
mi= tonegen(1200, 441000, 2);
hi= tonegen(11000, 441000, 2);
soundsc(lo, 441000);
soundsc(mi, 441000);
soundsc(hi, 441000);

