%An example set of LSPs (used to plot many of the figures in the book)

lsp=[0.3644, 0.4023, 0.6335, 1.1674, 1.3725, 1.4205, 1.8111, 1.8876, 2.1032, 2.3801];
