%This is just a simple example of a 10th order LPC polynomial used to plot many of the figures in the book
a=[1;-1.6187;2.3179;-2.9555;2.8862; -2.5331;2.2299;-1.3271;0.9886;  -0.6126;0.2354];

