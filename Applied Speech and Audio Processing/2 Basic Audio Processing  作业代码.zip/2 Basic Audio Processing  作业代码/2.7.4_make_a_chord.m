C=tonegen(261.63, 8000, 2);
E=tonegen(329.63, 8000, 2);
G=tonegen(783.99, 8000, 2);
B=tonegen(987.77, 8000, 2);
soundsc(C+E+G+B, 8000);

